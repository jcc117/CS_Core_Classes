#ifndef _MYMALLOC_H_
#define _MYMALLOC_H_
//Jordan Carr
//jcc117
void* my_malloc(unsigned int size);
void my_free(void* ptr);

#endif