/*
	FUSE: Filesystem in Userspace
	Copyright (C) 2001-2007  Miklos Szeredi <miklos@szeredi.hu>

	This program can be distributed under the terms of the GNU GPL.
	See the file COPYING.
*/

/*
	Jordan Carr
	jcc117
	CS1550
	Project 4
*/

#define	FUSE_USE_VERSION 26

#include <fuse.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>

//size of a disk block
#define	BLOCK_SIZE 512

//we'll use 8.3 filenames
#define	MAX_FILENAME 8
#define	MAX_EXTENSION 3

//How many files can there be in one directory?
#define MAX_FILES_IN_DIR (BLOCK_SIZE - sizeof(int)) / ((MAX_FILENAME + 1) + (MAX_EXTENSION + 1) + sizeof(size_t) + sizeof(long))

//The attribute packed means to not align these things
struct cs1550_directory_entry
{
	int nFiles;	//How many files are in this directory.
				//Needs to be less than MAX_FILES_IN_DIR

	struct cs1550_file_directory
	{
		char fname[MAX_FILENAME + 1];	//filename (plus space for nul)
		char fext[MAX_EXTENSION + 1];	//extension (plus space for nul)
		size_t fsize;					//file size
		long nStartBlock;				//where the first block is on disk
	} __attribute__((packed)) files[MAX_FILES_IN_DIR];	//There is an array of these

	//This is some space to get this to be exactly the size of the disk block.
	//Don't use it for anything.  
	char padding[BLOCK_SIZE - MAX_FILES_IN_DIR * sizeof(struct cs1550_file_directory) - sizeof(int)];
} ;

typedef struct cs1550_root_directory cs1550_root_directory;

#define MAX_DIRS_IN_ROOT (BLOCK_SIZE - sizeof(int)) / ((MAX_FILENAME + 1) + sizeof(long))

struct cs1550_root_directory
{
	int nDirectories;	//How many subdirectories are in the root
						//Needs to be less than MAX_DIRS_IN_ROOT
	struct cs1550_directory
	{
		char dname[MAX_FILENAME + 1];	//directory name (plus space for nul)
		long nStartBlock;				//where the directory block is on disk
	} __attribute__((packed)) directories[MAX_DIRS_IN_ROOT];	//There is an array of these

	//This is some space to get this to be exactly the size of the disk block.
	//Don't use it for anything.  
	char padding[BLOCK_SIZE - MAX_DIRS_IN_ROOT * sizeof(struct cs1550_directory) - sizeof(int)];
} ;


typedef struct cs1550_directory_entry cs1550_directory_entry;

//How much data can one block hold?
#define	MAX_DATA_IN_BLOCK (BLOCK_SIZE - sizeof(long))

struct cs1550_disk_block
{
	//The next disk block, if needed. This is the next pointer in the linked 
	//allocation list
	long nNextBlock;

	//And all the rest of the space in the block can be used for actual data
	//storage.
	char data[MAX_DATA_IN_BLOCK];
};

typedef struct cs1550_disk_block cs1550_disk_block;

/*
 * Called whenever the system wants to know the file attributes, including
 * simply whether the file exists or not. 
 *
 * man -s 2 stat will show the fields of a stat structure
 */
static int cs1550_getattr(const char *path, struct stat *stbuf)
{
	int res = 0;

	memset(stbuf, 0, sizeof(struct stat));
   
	//is path the root dir?
	if (strcmp(path, "/") == 0) {
		stbuf->st_mode = S_IFDIR | 0755;
		stbuf->st_nlink = 2;
		stbuf->st_size = BLOCK_SIZE;
		stbuf->st_blksize = BLOCK_SIZE;
		stbuf->st_blocks = 1;
	} else {

	//Check if name is subdirectory

	//Read in the root from disk
		FILE *file = fopen(".disk", "rb");
		cs1550_root_directory root;
		fread(&root, sizeof(root), 1, file);

		//printf("num dirs- %d\n", root.nDirectories);

		//Check subdirectories actually exist
		if(root.nDirectories == 0)
		{
			fclose(file);
			return -ENOENT;
		}

		//Parse the path to get the name of the subdirectory
		//printf("%s\n", path);
		char subname[MAX_FILENAME];
		char filename[MAX_FILENAME];
		char ext[MAX_EXTENSION];
		int num = sscanf(path, "/%[^/]/%[^.].%s", subname, filename, ext);
		//printf("num scanned: %d\n", num);

	//Check if the subdirectory exists
		int found = 0;
		int i;
		for(i = 0; i < root.nDirectories; i++)
		{
			//printf("%s, %s\n", subname, root.directories[i].dname);
			if(strcmp(root.directories[i].dname, subname) == 0)
			{
				found = 1;
				break;
			}
		}
		//Check if the subdirectory was found
		if(found)
		{
			//If filename is null, no file was specified in the path and what is requested is a directory
			if(num == 1)
			{
				//This block is originally commented out
				//Might want to return a structure with these fields
				//printf("I'm a directory that exists\n");
				stbuf->st_mode = S_IFDIR | 0755;
				stbuf->st_nlink = 2;
				stbuf->st_blksize = BLOCK_SIZE;
				stbuf->st_blocks = 1;
				stbuf->st_size = BLOCK_SIZE;
				res = 0; //no error
			}
			else
			{
				//printf("I'm a file\n");

				//Look up the files in this directory to see if the file exists
				fseek(file, root.directories[i].nStartBlock, SEEK_SET);
				cs1550_directory_entry dir;
				fread(&dir, sizeof(cs1550_directory_entry), 1, file);

				//Make sure the directory has files
				if(dir.nFiles == 0 || ext == NULL)
				{
					return -ENOENT;
				}

				int j;
				found = 0;
				for(j = 0; j < dir.nFiles; j++)
				{
					if(strcmp(dir.files[j].fname, filename) == 0 && strcmp(dir.files[j].fext, ext) == 0)
					{
						found = 1;
						break;
					}
				}

				if(found)
				{
					//This block is originally commented out
					//Check if name is a regular file
					//regular file, probably want to be read and write
					//printf("I'm a file that exists\n");
					stbuf->st_mode = S_IFREG | 0666; 
					stbuf->st_nlink = 1; //file links
					stbuf->st_size = dir.files[j].fsize; //file size - make sure you replace with real size!
					stbuf->st_blocks = (dir.files[j].fsize + (BLOCK_SIZE / 2)) / BLOCK_SIZE;	//Round up the number of blocks needed
					stbuf->st_blksize = BLOCK_SIZE;
					res = 0; // no error
				}
				else
					return -ENOENT;
			}
		}
		else
		{
			//Else return that path doesn't exist
			res = -ENOENT;
		}
		fclose(file);
	}
	return res;
}

/* 
 * Called whenever the contents of a directory are desired. Could be from an 'ls'
 * or could even be when a user hits TAB to do autocompletion
 */
static int cs1550_readdir(const char *path, void *buf, fuse_fill_dir_t filler,
			 off_t offset, struct fuse_file_info *fi)
{
	//Since we're building with -Wall (all warnings reported) we need
	//to "use" every parameter, so let's just cast them to void to
	//satisfy the compiler
	(void) offset;
	(void) fi;

	FILE *file = fopen(".disk", "rb");

	//Read in the root to get the subdirectories
	cs1550_root_directory root;
	fread(&root, sizeof(root), 1, file);

	//This line assumes we have no subdirectories, need to change
	if (strcmp(path, "/") == 0)
	{
		//return -ENOENT;
		int i;
		for(i = 0; i < root.nDirectories; i++)
		{
			filler(buf, root.directories[i].dname, NULL, 0);
		}
	}
	else
	{
		//Check the path to see if its a directory
		char directory[MAX_FILENAME];
		char fname[MAX_FILENAME];
		char extension[MAX_EXTENSION];
		int num = sscanf(path, "/%[^/]/%[^.].%s", directory, fname, extension);

		//Indicates the path is a file
		if(num > 1)
		{
			fclose(file);
			return -ENOENT;
		}
		else
		{
			//Make sure the subdirectory exists
			int found = 0;
			int i;
			for(i = 0; i < root.nDirectories; i++)
			{
				if(strcmp(directory, root.directories[i].dname) == 0)
				{
					found = 1;
					break;
				}
			}
			if(found)
			{
				//Go to that specific block and get its directories
				fseek(file, root.directories[i].nStartBlock, SEEK_SET);
				cs1550_directory_entry dir;
				fread(&dir, sizeof(dir), 1, file);

				//Put the contents of the directory in the list
				int j;
				for(j = 0; j < dir.nFiles; j++)
				{
					char* filename = dir.files[j].fname;
					strcat(filename, ".");
					strcat(filename, dir.files[j].fext);
					filler(buf, filename, NULL, 0);
				}
			}
			else
			{
				fclose(file);
				return -ENOENT;
			}
		}
	}
	//the filler function allows us to add entries to the listing
	//read the fuse.h file for a description (in the ../include dir)
	filler(buf, ".", NULL, 0);
	filler(buf, "..", NULL, 0);

	/*
	//add the user stuff (subdirs or files)
	//the +1 skips the leading '/' on the filenames
	filler(buf, newpath + 1, NULL, 0);
	*/
	fclose(file);
	return 0;
}

/* 
 * Creates a directory. We can ignore mode since we're not dealing with
 * permissions, as long as getattr returns appropriate ones for us.
 */
static int cs1550_mkdir(const char *path, mode_t mode)
{
	//(void) path;
	(void) mode;

	//printf("%s\n", path);
	
	//Check the length of its name
	char directory[MAX_FILENAME + 1];
	char fname[MAX_FILENAME + 1];
	char extension[MAX_EXTENSION + 1];

	int num = sscanf(path, "/%[^/]/%[^.].%s", directory, fname, extension);
	//printf("%s, %s, %s\n", directory, fname, extension);

	if(num > 1)
		return -EPERM;
	if(strlen(directory) > MAX_FILENAME)
		return -ENAMETOOLONG;

	//printf("Not too long, able to be made\n");

	FILE *file = fopen(".disk", "rb");
	cs1550_root_directory root;
	fread(&root, sizeof(root), 1, file);
	fclose(file);

	//Maker sure this directory doesn't already exist
	int i;
	for(i = 0; i < root.nDirectories; i++)
	{
		//printf("%s, %s\n", directory, root.directories[i].dname);

		if(strcmp(directory, root.directories[i].dname) == 0)
			return -EEXIST;
	}

	//printf("Doesn't already exist\n");

	//Make the new directory in root
	if(root.nDirectories == MAX_DIRS_IN_ROOT)
		return -ENOSPC;

	//Set up the directory in the root directory
	root.directories[root.nDirectories].nStartBlock = (BLOCK_SIZE * (root.nDirectories + 1));
	int k;
	for(k = 0; k < MAX_FILENAME + 1; k++)
	{
		root.directories[root.nDirectories].dname[k] = directory[k];
		if(directory[k] == '\0')
			break;
	}
	root.nDirectories++;

	cs1550_directory_entry entry = {.nFiles = 0};

	//Set up the directory on disk
	FILE *wFile = fopen(".disk", "wb");
	fwrite(&root, sizeof(root), 1, wFile);
	fseek(wFile, root.directories[root.nDirectories - 1].nStartBlock, SEEK_SET);
	fwrite(&entry, sizeof(entry), 1, wFile);
	fclose(wFile);

	//printf("Everything set up\n");

	return 0;
}

/* 
 * Removes a directory.
 */
static int cs1550_rmdir(const char *path)
{
	(void) path;
    return 0;
}

/* 
 * Does the actual creation of a file. Mode and dev can be ignored.
 *
 */
static int cs1550_mknod(const char *path, mode_t mode, dev_t dev)
{
	(void) mode;
	(void) dev;
	(void) path;
	return 0;
}

/*
 * Deletes a file
 */
static int cs1550_unlink(const char *path)
{
    (void) path;

    return 0;
}

/* 
 * Read size bytes from file into buf starting from offset
 *
 */
static int cs1550_read(const char *path, char *buf, size_t size, off_t offset,
			  struct fuse_file_info *fi)
{
	(void) buf;
	(void) offset;
	(void) fi;
	(void) path;

	//check to make sure path exists
	//check that size is > 0
	//check that offset is <= to the file size
	//read in data
	//set size and return, or error

	size = 0;

	return size;
}

/* 
 * Write size bytes from buf into file starting from offset
 *
 */
static int cs1550_write(const char *path, const char *buf, size_t size, 
			  off_t offset, struct fuse_file_info *fi)
{
	(void) buf;
	(void) offset;
	(void) fi;
	(void) path;

	//check to make sure path exists
	//check that size is > 0
	//check that offset is <= to the file size
	//write data
	//set size (should be same as input) and return, or error

	return size;
}

/******************************************************************************
 *
 *  DO NOT MODIFY ANYTHING BELOW THIS LINE
 *
 *****************************************************************************/

/*
 * truncate is called when a new file is created (with a 0 size) or when an
 * existing file is made shorter. We're not handling deleting files or 
 * truncating existing ones, so all we need to do here is to initialize
 * the appropriate directory entry.
 *
 */
static int cs1550_truncate(const char *path, off_t size)
{
	(void) path;
	(void) size;

    return 0;
}


/* 
 * Called when we open a file
 *
 */
static int cs1550_open(const char *path, struct fuse_file_info *fi)
{
	(void) path;
	(void) fi;
    /*
        //if we can't find the desired file, return an error
        return -ENOENT;
    */

    //It's not really necessary for this project to anything in open

    /* We're not going to worry about permissions for this project, but 
	   if we were and we don't have them to the file we should return an error

        return -EACCES;
    */

    return 0; //success!
}

/*
 * Called when close is called on a file descriptor, but because it might
 * have been dup'ed, this isn't a guarantee we won't ever need the file 
 * again. For us, return success simply to avoid the unimplemented error
 * in the debug log.
 */
static int cs1550_flush (const char *path , struct fuse_file_info *fi)
{
	(void) path;
	(void) fi;

	return 0; //success!
}


//register our new functions as the implementations of the syscalls
static struct fuse_operations hello_oper = {
    .getattr	= cs1550_getattr,
    .readdir	= cs1550_readdir,
    .mkdir	= cs1550_mkdir,
	.rmdir = cs1550_rmdir,
    .read	= cs1550_read,
    .write	= cs1550_write,
	.mknod	= cs1550_mknod,
	.unlink = cs1550_unlink,
	.truncate = cs1550_truncate,
	.flush = cs1550_flush,
	.open	= cs1550_open,
};

//Don't change this.
int main(int argc, char *argv[])
{
	return fuse_main(argc, argv, &hello_oper, NULL);
}
